package org.xmart.objc.annotation;

public @interface Uint8 {

}
