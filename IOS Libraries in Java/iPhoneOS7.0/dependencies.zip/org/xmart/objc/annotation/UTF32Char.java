package org.xmart.objc.annotation;

public @interface UTF32Char {

}
