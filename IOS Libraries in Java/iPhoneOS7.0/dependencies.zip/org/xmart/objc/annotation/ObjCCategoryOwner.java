package org.xmart.objc.annotation;

public @interface ObjCCategoryOwner {

	String value();

}
