package org.xmart.objc.type;


public class ObjCPtr<T> extends ObjCObject {

}
