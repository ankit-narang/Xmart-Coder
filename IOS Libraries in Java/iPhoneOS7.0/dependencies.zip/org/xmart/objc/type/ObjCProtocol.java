package org.xmart.objc.type;

public interface ObjCProtocol {

}
