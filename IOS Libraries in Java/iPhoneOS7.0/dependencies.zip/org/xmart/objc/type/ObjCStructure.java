package org.xmart.objc.type;

public class ObjCStructure extends ObjCObject {

}
