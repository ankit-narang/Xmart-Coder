package org.xmart.objc.type;

public class ObjCObject {

}
