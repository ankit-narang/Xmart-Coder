package org.xmart.objc.type;


public final class ObjCBlock extends ObjCObject {
}
