package org.xmart.objc.type;


public final class ObjCFunctionPtr extends ObjCObject {

}
